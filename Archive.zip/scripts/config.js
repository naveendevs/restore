config : {
  database : {
    name : 'reliquaStore',
    path : './'
  }
}
